package fyp.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
public class PointsRewardedController {

	@Autowired
	private PointsRewardedService pointsRewardedService;

	@Autowired
	private MemberRepository memberRepository;
	
	@Autowired
	private ActivityService activityService; 
	@GetMapping("/pointsRewarded")
	public String showPointsRewardedForm(Model model) {
		// Fetch all activities
		List<Activities> activities = activityService.getAllActivities();
		model.addAttribute("activities", activities);
		return "pointsRewarded"; // View name
	}

	@PostMapping("/pointsRewarded/save")
	public String savePoints(@ModelAttribute PointsRewarded pointsRewarded, RedirectAttributes redirectAttributes) {
		Member member = memberRepository.findById(pointsRewarded.getMember().getId()).orElse(null);

		if (member != null) {
			try {
				// Convert String to int and add points
				int additionalPoints = Integer.parseInt(pointsRewarded.getPointsRewardedForm());
				int updatedPoints = member.getPoints() + additionalPoints;
				member.setPoints(updatedPoints);
				memberRepository.save(member);

				redirectAttributes.addFlashAttribute("successMessage", "Points rewarded successfully!");
			} catch (NumberFormatException e) {
				redirectAttributes.addFlashAttribute("errorMessage", "Invalid points value.");
			}
		} else {
			redirectAttributes.addFlashAttribute("errorMessage", "Member not found.");
		}

		return "redirect:/history"; // Redirect to the history page after rewarding points
	}

	@GetMapping("/getMemberPoints")
	@ResponseBody
	public Map<String, Integer> getMemberPoints(@RequestParam Integer memberId) { // Changed Long to Integer
		Member member = memberRepository.findById(memberId).orElse(null);
		Map<String, Integer> response = new HashMap<>();
		response.put("totalPoints", (member != null) ? member.getPoints() : 0);
		return response;
	}

}
