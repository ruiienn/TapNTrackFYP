/**
 * 
 * I declare that this code was written by me, xandr. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: xandra
 * Student ID: 22022591
 * Date created: 2024-Nov-13 4:22:43 pm 
 * 
 */
package fyp.admin;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author xandr
 *
 */
public interface ActivitiesRepository extends JpaRepository<Activities, Integer> {

}
