package fyp.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@RestController
public class PointsApiController {

	@Autowired
	private MemberRepository memberRepository;

	@Autowired
	private PointsRewardedService pointsRewardedService;

	/**
	 * Retrieves the total points of a member. If `memberId` is provided, fetches by
	 * ID. Otherwise, fetches the logged-in user's points.
	 */
	@GetMapping("/api/member/points")
	public int getMemberPoints(@RequestParam(required = false) Integer memberId, Principal principal) {
		Member member = null;

		// If `memberId` is provided, fetch by ID
		if (memberId != null) {
			member = memberRepository.findById(memberId).orElse(null);
		}
		// Otherwise, use the currently logged-in user's ID
		else if (principal != null) {
			String username = principal.getName();
			member = memberRepository.findByUsername(username);
		}

		// Return the calculated points or 0 if member not found
		return (member != null) ? pointsRewardedService.calculateTotalPoints(member) : 0;
	}

	/**
	 * Retrieves both the member's total points and their points history. Can be
	 * used to update both points and history dynamically.
	 */
	@GetMapping("/api/member/points-history")
	public PointsHistoryResponse getMemberPointsWithHistory(@RequestParam(required = false) Integer memberId,
			Principal principal) {
		Member member = null;

		if (memberId != null) {
			member = memberRepository.findById(memberId).orElse(null);
		} else if (principal != null) {
			String username = principal.getName();
			member = memberRepository.findByUsername(username);
		}

		// If member exists, return their total points & history
		if (member != null) {
			int totalPoints = pointsRewardedService.calculateTotalPoints(member);
			List<PointsRewarded> history = pointsRewardedService.getMemberPointsHistory(member);
			return new PointsHistoryResponse(totalPoints, history);
		}

		// Return empty history if member not found
		return new PointsHistoryResponse(0, new ArrayList<>());
	}

	/**
	 * Response DTO for returning member points and history.
	 */
	public static class PointsHistoryResponse {
		private int totalPoints;
		private List<PointsRewarded> history;

		public PointsHistoryResponse(int totalPoints, List<PointsRewarded> history) {
			this.totalPoints = totalPoints;
			this.history = history;
		}

		public int getTotalPoints() {
			return totalPoints;
		}

		public List<PointsRewarded> getHistory() {
			return history;
		}
	}
}
